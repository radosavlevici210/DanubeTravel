# PROPRIETARY SOFTWARE LICENSE

## Perla Dunării AI Tourism Platform
© 2025 radosavlevici210. All Rights Reserved.

Unauthorized copying, modification, distribution, or use is strictly prohibited.
